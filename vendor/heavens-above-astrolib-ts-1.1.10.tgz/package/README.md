# astrolib

## Introduction

An astrodynamics library, written in TypeScript.
It is based on the C# code used for the Heavens-Above web site and the Satmon orbit displays.

## Installation

Install the library with [NPM](https://www.npmjs.com/):

```bash
npm instal lastrolib
```

Install the library with [Yarn](https://yarnpkg.com/):

```bash
yarn add astrolib
```

Install the library with [Bower](http://bower.io/):

```bash
bower install astrolib
```
